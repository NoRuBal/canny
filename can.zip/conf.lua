-- conf.lua
-- 게임 창의 설정, 최적화를 위한 모듈 사용 설정 등.

function love.conf(t)
    t.title = "Canny the can's adventure!"
    t.screen.width = 816
    t.screen.height = 480
end
